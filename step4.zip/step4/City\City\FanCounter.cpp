/**
 * \file FanCounter.cpp
 *
 * \author kunyu chen
 */

#include "stdafx.h"
#include "FanCounter.h"

/**
* Constructor
*/
CFanCounter::CFanCounter()
{
}

/**
* Destructor
*/
CFanCounter::~CFanCounter()
{
}

/** Visit a CTileBigten object
* \param fan fan we are visiting */
void CFanCounter::VisitFan(CTileBigten *fan)
{
	mNumFans++;
}


