/**
 * \file NewSeasonVisitor.h
 *
 * \author kunyu chen
 *
 * Class that implements the new season menu option
 */

#pragma once
#include "TileVisitor.h"

/**
 * start a new season 
 */
class CNewSeasonVisitor :
	public CTileVisitor
{
public:
	///constructor
	CNewSeasonVisitor();
	virtual ~CNewSeasonVisitor();
	/** visit fan tile*/
	virtual void VisitFan(CTileBigten *fan) override;
};



