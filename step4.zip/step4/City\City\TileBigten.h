/**
 * \file TileBigten.h
 *
 * \author kunyu chen
 *
 * 
 */


#pragma once

#include "Tile.h"

/**
 * control fan's action 
 */
class CTileBigten :	public CTile
{
public:
	CTileBigten(CCity *city);

	///  Default constructor (disabled)
	CTileBigten() = delete;

	///  Copy constructor (disabled)
	CTileBigten(const CTileBigten &) = delete;

	virtual ~CTileBigten();

	virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
	virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode> &node);

	void LoadImage(std::unique_ptr<Gdiplus::Bitmap> &image, std::wstring name);

	virtual void Draw(Gdiplus::Graphics *graphics);

	void Update(double elapsed);
	/// declared the two image
	enum States { Guy1, Guy2 };

	/** Accept a visitor
	* \param visitor The visitor we accept */
	virtual void Accept(CTileVisitor *visitor) override { visitor->VisitFan(this); }
	///when play use image two 
	void Play() { mState = Guy2; }
	///newseason use image one
	void NewSeason() { mState = Guy1, mRunAway = false; }
	///set run away
	bool SetRunAway() { return mRunAway = true; }
	/// reset run. 
	void ResetRunX() { mRunX = 0; }
	
	
private:
	/// The image of the umguy1
	std::unique_ptr<Gdiplus::Bitmap> mGuy1Image;

	/// The image of the umguy2
	std::unique_ptr<Gdiplus::Bitmap> mGuy2Image;

	///decide which guy need to be draw
	States mState = Guy1;

	/// Fan speed in the X direction
	double mSpeedX = 0;

	/// Fan speed in the X direction
	double mRSpeedX = 0;

	/// fan's runaway speed
	int mRunX = 0;

	/// if true the fan runaway
	bool mRunAway = false;
	/// Fan's direction 
	double direction = 0;

};



