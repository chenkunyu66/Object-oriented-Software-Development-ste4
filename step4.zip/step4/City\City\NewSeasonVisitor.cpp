/**
 * \file NewSeasonVisitor.cpp
 *
 * \author kunyu chen
 */

#include "stdafx.h"
#include "NewSeasonVisitor.h"
#include "TileBigten.h"

/**
* Constructor
*/
CNewSeasonVisitor::CNewSeasonVisitor()
{
}

/**
* Destructor
*/
CNewSeasonVisitor::~CNewSeasonVisitor()
{
}

/** \brief Visit a fan object
* \param fan fan tile we are visiting */
void CNewSeasonVisitor::VisitFan(CTileBigten *fan)
{
	fan->NewSeason();
	fan->ResetTimesPlayed();
	fan->ResetRunX();
}
