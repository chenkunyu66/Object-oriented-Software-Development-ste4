/**
 * \file TileVisitor.cpp
 *
 * \author kunyu chen
 */

#include "stdafx.h"
#include "TileVisitor.h"


CTileVisitor::CTileVisitor()
{
}


CTileVisitor::~CTileVisitor()
{
}
