/**
 * \file FanCounter.h
 *
 * \author kunyu chen
 *
 * Class that implements the Michigan Fan
 */


#pragma once
#include "TileVisitor.h"

/**
 * count the number of fan
 */
class CFanCounter :
	public CTileVisitor
{
public:
	CFanCounter();
	virtual ~CFanCounter();

	/** Get the number of fans
	* \returns Number of fans */
	int GetNumFans() const { return mNumFans; }
	/** visit fans */
	void VisitFan(CTileBigten *fan);

private:
	/// Buildings counter
	int mNumFans = 0;
};



