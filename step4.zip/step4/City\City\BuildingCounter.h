/**
 * \file BuildingCounter.h
 *
 * \author kunyu chen
 *
 * Class that implements the counter for buildings
 */


#pragma once
#include "TileVisitor.h"

/**
 * count building number
 */
class CBuildingCounter :
	public CTileVisitor
{
public:
	CBuildingCounter();
	virtual ~CBuildingCounter();


	/** Get the number of buildings
	* \returns Number of buildings */
	int GetNumBuildings() const { return mNumBuildings; }

	void VisitBuilding(CTileBuilding *building);

private:
	/// Buildings counter
	int mNumBuildings = 0;

};


