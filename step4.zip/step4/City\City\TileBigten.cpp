/**
 * \file TileBigten.cpp
 *
 * \author kunyu chen
 */



#include "stdafx.h"
#include "TileBigten.h"
#include "PlayTileVisitor.h"
#include "FanCounter.h"
#include "Tile.h"
#include "City.h"

using namespace std;
using namespace Gdiplus;

/// Image for background
const wstring TileBackground = L"grass.png";

/// Image for umguy1
const wstring Guy1Image = L"umguy1.png";

/// Image for umguy2
const wstring Guy2Image = L"umguy2.png";

/// Maximum speed in the positive X 
/// in pixels per second
const double MaxSpeedX = 800;

/// Minimum speed in the positive X
/// in pixels per second
const double MinSpeedX = 700;

/// Maximum speed in the negative X
/// in pixels per second
const double RMaxSpeedX = -800;

/// Minimum speed in the negative X
/// in pixels per second
const double RMinSpeedX = -700;

/// The number that decides which direction the minion runs
const double postiv = 2;
/// The number that decides which direction the minion runs
const double negat = -2;

/** Constructor
* \param city The city this is a member of
*/
CTileBigten::CTileBigten(CCity *city) : CTile(city)
{
	SetImage(TileBackground);

	LoadImage(mGuy1Image, Guy1Image);
	LoadImage(mGuy2Image, Guy2Image);

	mSpeedX = MinSpeedX + ((double)rand() / RAND_MAX) * (MaxSpeedX - MinSpeedX);
	mRSpeedX = RMinSpeedX + ((double)rand() / RAND_MAX) * (RMaxSpeedX - RMinSpeedX);
	direction =  negat + ((double)rand() / RAND_MAX) * (postiv - negat);
}

/**
*  Destructor
*/
CTileBigten::~CTileBigten()
{
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CTileBigten::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CTile::XmlSave(node);

	itemNode->SetAttribute(L"type", L"fan");
	itemNode->SetAttribute(L"file", GetFile());

	return itemNode;
}


/**
* brief Load the attributes for an item node.
* \param node The Xml node we are loading the item from
*/
void CTileBigten::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	CTile::XmlLoad(node);
	SetImage(node->GetAttributeValue(L"file", L""));
}

/**
* Load an image into a bitmap
* \param image Image pointer to load
* \param name Filename to load from
*/
void CTileBigten::LoadImage(std::unique_ptr<Gdiplus::Bitmap> &image, std::wstring name)
{
	wstring filename = ImagesDirectory + name;
	image = unique_ptr<Bitmap>(Bitmap::FromFile(filename.c_str()));
	if (image->GetLastStatus() != Ok)
	{
		wstring msg(L"Failed to open ");
		msg += filename;
		AfxMessageBox(msg.c_str());
	}
}

/** Draw this item
* \param graphics The graphics context to draw on */
void CTileBigten::Draw(Gdiplus::Graphics *graphics)
{
	CTile::Draw(graphics);
	if (mState == Guy1)
	{
		int wid = mGuy1Image->GetWidth();
		int hit = mGuy1Image->GetHeight();

		graphics->DrawImage(mGuy1Image.get(),
			(int)(GetX() - OffsetLeft), (int)(GetY() + OffsetDown - hit), wid, hit);
	}
	else
	{
		int wid = mGuy2Image->GetWidth();
		int hit = mGuy2Image->GetHeight();

		graphics->DrawImage(mGuy2Image.get(),
			(int)(GetX() - OffsetLeft) + mRunX, (int)(GetY() + OffsetDown - hit), wid, hit);
	}
}

/**
* Called before the image is drawn
* \param elapsed Time since last draw
*/
void CTileBigten::Update(double elapsed)
{
	CTile::Update(elapsed);

	// when the Minion is running...
	// mSpeedX is a constant pixels per second running speed...
	if (mRunAway)
	{
		// Run to right if the random number is positive
		if (direction > 0)
		{
			mRunX += mSpeedX * elapsed;	
		}
		// Run to left otherwise
		else
		{
			mRunX += mRSpeedX * elapsed;
		}	
	}

}





