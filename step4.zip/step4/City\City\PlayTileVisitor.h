/**
 * \file PlayTileVisitor.h
 *
 * \author kunyu chen
 *
 * Class that implements the visitor for Michigan Fan tile
 */

#pragma once
#include "TileVisitor.h"


/**
 * Visit a CTileLandscape object to check how much time it was chacked
 */
class CPlayTileVisitor :
	public CTileVisitor
{
public:
	/** visiting the Landscape tile
	*\param needsPlay number of play
	*/
	CPlayTileVisitor(int needsPlay) { mTileNeedsPlays = needsPlay; }
	virtual virtual ~CPlayTileVisitor();

	/** visiting the Landscape tile
	*\param fan visiting fan*/
	virtual void VisitFan(CTileBigten *fan) override;


private:
	///the fan played after the first check
	int mTileNeedsPlays = 0;

};


