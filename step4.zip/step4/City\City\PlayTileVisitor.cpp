/**
 * \file PlayTileVisitor.cpp
 *
 * \author kunyu chen
 */

#include "stdafx.h"
#include "PlayTileVisitor.h"
#include "TileBigten.h"

/**
* Destructor
*/
CPlayTileVisitor::~CPlayTileVisitor()
{
}

/** \brief Visit a CTileLBigten object
* \param fan visiting the Landscape tile */
void CPlayTileVisitor::VisitFan(CTileBigten *fan)
{
	if (fan->TimesPlayed() > mTileNeedsPlays)
	{
		fan->SetRunAway();
	}
	fan->Play();
}
