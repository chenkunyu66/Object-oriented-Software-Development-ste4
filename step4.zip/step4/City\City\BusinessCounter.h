/**
 * \file BusinessCounter.h
 *
 * \author kunyu chen
 *
 * 
 */

#pragma once
#include "TileVisitor.h"

/**
 * To count the number of business 
 */
class CBusinessCounter : public CTileVisitor
{
public:
	CBusinessCounter();
	virtual ~CBusinessCounter();

	/** Get the number of buildings
	* \returns Number of buildings */
	int GetNumCoalmines() const { return mNumCoalmines; }

	void VisitCoalmine(CTileCoalmine *coalmine);

private:
	/// Buildings counter
	int mNumCoalmines = 0;
};

