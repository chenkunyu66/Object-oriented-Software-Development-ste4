/**
 * \file BusinessCounter.cpp
 *
 * \author kunyu chen
 */


#include "stdafx.h"
#include "BusinessCounter.h"


CBusinessCounter::CBusinessCounter()
{
}


CBusinessCounter::~CBusinessCounter()
{
}

/** Visit a CTileCoalmine object
* \param coalmine Coalmine we are visiting */
void CBusinessCounter::VisitCoalmine(CTileCoalmine *coalmine)
{
	mNumCoalmines++;
}

